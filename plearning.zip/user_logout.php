<?php
require_once 'library/config.php';
require_once 'library/login-functions.php';
    us_doLogout();
?>
