<?php
//require_once 'library/config.php';
//require_once '../library/database.php'; 
//echo "Jai Shri Ram";
//$Q_id= $_GET['QID'];
//$N= $_GET['N'];
//$ret=array();
//$ret[0]="<table>";   
//$sql= "select questiontext, `type`, answer from questions where Q_id='$Q_id';";
//$result1= dbQuery($sql) or die('Cannot get questions. ' . mysql_error())    ;
//  extract(mysql_fetch_assoc($result1));
//
//$ret[0]=$ret[0]."<tr><td style=\"float: left; width: 40px\"><b>Q.".$N.".</b></td> <td colspan=\"2\">".$questiontext."</td></tr>";
//            
//if($type=='O'){
//    $sql= "select A,B,C,D,E from answer_objective where Q_id='$Q_id';";
//    $result2= dbQuery($sql) or die('Cannot get options. ' . mysql_error());
//    extract(mysql_fetch_assoc($result2));
//    $ret[0]=$ret[0]."<tr><td>   </td><td> <input type=\"radio\" value=\"A\" name= \"corans\"/></td><td><b>".$A."</b></td></tr>";
//    $ret[0]=$ret[0]."<tr><td>   </td><td> <input type=\"radio\" value=\"B\" name= \"corans\"/></td><td>".$B."</td></tr>";
//    $ret[0]=$ret[0]."<tr><td>   </td><td> <input type=\"radio\" value=\"C\" name= \"corans\"/></td><td>".$C."</td></tr>";
//    $ret[0]=$ret[0]."<tr><td>   </td><td> <input type=\"radio\" value=\"D\" name= \"corans\"/></td><td>".$D."</td></tr>";
//    $ret[0]=$ret[0]."<tr><td>   </td><td> <input type=\"radio\" value=\"E\" name= \"corans\"/></td><td>".$E."</td></tr>";
//        }
//$ret[0]=$ret[0]."</table>";
//$ret[1]=$answer;
//$ret[2]=$type;
//echo json_encode($ret);
?>

    
  


    