<?php


?>
<div style="margin-top:0px;line-height:70px ;
     height:55px;background-color:#efebeb; position:relative; align:center;margin:0 auto;box-shadow: inset 0 10px 10px -10px #000000;"><p style="width:600px; color:rgb(31, 75, 116) ;  font-size:30px;align:center;  text-shadow:#f9f9f9 0px 0px 2px;">Courses Available</p></div>
<div class="coursebuttons_wrapper" style="margin-left: 270px; height: 200px; margin-bottom: 50px;">
    <div class="coursebuttons" style="text-align: center">
        <a href="/index.php?c=1"> 
            <div style="margin: 50px 0;">
            <div style="color: crimson;font-size: 15px">Calculus-I </div>
            <div style="color: black">Mathematics-I</div>
            </div>
        </a>
    </div>
</div>
