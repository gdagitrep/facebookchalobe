<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="panel1" style="clear: both; margin-top:0px; width:100%; height:auto; text-align:center; background: url('/images/bg_footer2.png') repeat scroll 0 0 transparent;"><div style="width:980px;margin:0 auto;">
        <div id="pp" style="margin-top:20px;;;width:650px;float:left;">
            <h3>Quick Links </h3>
            <div style=" text-align:left;">
                <div style="margin-left:0px; margin-top:10px; ">
                    <div style=" float:left">
                        <table style=" width:650px;height:99%;color:#ccc; ">
                            <tbody>
                                <tr><td style="width:120px;"> <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto; font-family:'Oxygen', sans-serif; font-size:13px;"> <a href="/gifts/youthmarried/justlikethat/friendher" style="color:#888888; text-decoration:none;">A</a> </h5> </td>
                                    <td style="width:120px;"> <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto; font-family:'Oxygen', sans-serif; font-size:13px;"> <a href="/gifts/youthmarried/justlikethat/friendhim" style="color:#888888; text-decoration:none;">B</a> </h5> </td>
                                    <td style="width:120px;"> <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto;font-family:'Oxygen', sans-serif; font-size:13px;"> <a href="/gifts/teenager/justlikethat/friendher" style="color:#888888; text-decoration:none;">C</a> </h5> </td>
                                    <td style="width:120px;"> <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto; font-family:'Oxygen', sans-serif; font-size:13px;"> <a href="/gifts/teenager/justlikethat/friendhim" style="color:#888888; text-decoration:none;">D</a> </h5> </td></tr>
                                <tr>
                                    <td style="width:120px;"> <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto; font-family:'Oxygen', sans-serif; font-size:13px;"> <a href="/admin/index.php" style="color:#888888; text-decoration:none;">Admin</a> </h5> </td>
                            </tbody>
                        </table></div></div></div></div>
        <div id="pp" style="width:250px;float:left;margin:20px;"><h3>Social Stuff </h3><br><div id="fb-root"></div>
            <script>(function(d, s, id) { var js, fjs = d.getElementsByTagName(s)[0]; if (d.getElementById(id)) return; js = d.createElement(s); js.id = id;js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=130457927150626";fjs.parentNode.insertBefore(js, fjs);}(document, 'script', 'facebook-jssdk'));</script>
            <div class="fb-like fb_edge_widget_with_comment fb_iframe_widget" data-colorscheme="dark" data-font="tahoma" data-href="https://www.facebook.com/Wishpickercom" data-send="true" data-show-faces="true" data-width="200" fb-xfbml-state="rendered"><span style="height: 79px; width: 285px;"><iframe id="f3baef6354" name="f76cb268" scrolling="no" title="Like this content on Facebook." class="fb_ltr" src="http://www.facebook.com/plugins/like.php?api_key=130457927150626&amp;locale=en_US&amp;sdk=joey&amp;channel_url=http%3A%2F%2Fstatic.ak.facebook.com%2Fconnect%2Fxd_arbiter.php%3Fversion%3D25%23cb%3Df1b5c83308%26origin%3Dhttp%253A%252F%252Fwww.wishpicker.com%252Ff3a531eed%26domain%3Dwww.wishpicker.com%26relation%3Dparent.parent&amp;href=https%3A%2F%2Fwww.facebook.com%2FWishpickercom&amp;node_type=link&amp;width=285&amp;font=tahoma&amp;layout=standard&amp;colorscheme=dark&amp;show_faces=true&amp;send=true&amp;extended_social_context=false" style="border: none; overflow: hidden; height: 79px; width: 285px;"></iframe></span></div><div style=" text-align:left;"><h5 style="color:#444444; cursor:default; margin-bottom:10px; font-family:'Oxygen', sans-serif; font-size:13px;color:white;"> Follow us on </h5><a class="facebook-round-gray-32 tsc_social_round_gray_link" href="http://www.facebook.com/Wishpickercom" style="color:red;" title="Follow us on Facebook">Follow us on Facebook</a> <a class="google-round-gray-32 tsc_social_round_gray_link" href="https://plus.google.com/114034066988086161620" rel="publisher" title="Follow us on Google+">Google+</a> <a class="pinterest-round-gray-32 tsc_social_round_gray_link" href="http://www.pinterest.com/wishpicker" title="Follow us on Pinterest">Follow us on Pinterest</a> <a class="rss-round-gray-32 tsc_social_round_gray_link" href="http://www.wishpicker.com/blog" title="Follow our Blog">Follow our Blog</a> <a class="twitter-round-gray-32 tsc_social_round_gray_link" href="http://www.twitter.com/wishpickergifts" title="Follow us on Twitter">Follow us on Twitter</a> </div>
                            <div id="pp" style="position:relative;width:250px;float:left;margin:20px 0 0 0;">
                                <h3>Know us </h3>
                                <div style=" text-align:left;">
                                    <div style="margin-left:15px; margin-top:10px; ">
                                        <div style="margin-left: auto; float:left">
                                            <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto; font-family:'Oxygen', sans-serif; font-size:13px; color:#888888;"> <a href="/contactus/" style="color:#888888; text-decoration:none;">Contact Us</a> </h5>
                                            <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto; font-family:'Oxygen', sans-serif; font-size:13px;"> <a href="/aboutus/" style="color:#888888; text-decoration:none;"> About Us</a> </h5> 
                                            <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto; font-family:'Oxygen', sans-serif; font-size:13px;"> <a href="/privacy/" style="color:#888888; text-decoration:none;">Privacy policy</a> </h5> 
                                            <h5 style="color:#444444; cursor:default; margin:auto auto 5px auto; font-family:'Oxygen', sans-serif; font-size:13px;"> <a href="/terms/" style="color:#888888; text-decoration:none;">Terms &amp; Conditions</a> </h5>
                                        </div></div></div></div></div>
                        
                        <div class="cl">
                            <br></div>
                        <div class="holder" style="width:100%; clear:both;overflow: hidden; margin:0 auto; padding: 8px 0; list-style: none;background:url('/images/static/c.png') repeat-x;"><ul class="panel" style="margin-left:-20px"><li style="float: left;font-size: 11px;line-height: 14px;color: #363636; padding: 0 14px 0 20px;"><strong style="color:white;">(C) 2013 CourseLamp.com</strong></li></ul></div></div>
</div>