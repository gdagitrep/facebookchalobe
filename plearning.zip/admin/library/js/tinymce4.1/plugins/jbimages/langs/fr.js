tinyMCE.addI18n('fr.jbimages',{
	desc : 'T\u00E9l\u00E9charger une image'
});